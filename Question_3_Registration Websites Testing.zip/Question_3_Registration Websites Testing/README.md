# Assignment_3_Registration website Testing

# Question 3.
# One of the registration websites requires your suggestion on the Usability aspects of their website.
# Functional Requirement:
Launch a new Browser.
Open URL https://www.bestundertaking.net/NewConnection.aspx
Provide your feedback/improvements/suggestions as a Functional Quality Engineer and as an End - User in terms of
Functionality 
Usability
UI Aesthetics



Answer - Covered following testing scenarios:
A] Functionality 
B] Usability
C] UI Aesthetics
